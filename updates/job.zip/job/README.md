# Introduction
- [Main Website](https://bhishanpoudel123.github.io)
- [Github Repo](https://github.com/bhishanpoudel123/bhishanpoudel123.github.io)

# Webapps
- [Stock Calculator](https://bhishanpoudel123.github.io/stock)
- [Job Calculator](https://bhishanpoudel123.github.io/job/)
